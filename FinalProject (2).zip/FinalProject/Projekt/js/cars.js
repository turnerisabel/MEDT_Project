let cars = [
    {
        name: "A-Klasse",
        image: "../images/aklasse_config.JPG"
    },
    {
        name: "B-Klasse",
        image: "../images/bklasse_config.JPG"
    },
    {
        name: "C-Klasse",
        image: "../images/cklasse_config.JPG"
    },
    {
        name: "E-Klasse",
        image: "../images/eklasse_config.JPG"
    }
]